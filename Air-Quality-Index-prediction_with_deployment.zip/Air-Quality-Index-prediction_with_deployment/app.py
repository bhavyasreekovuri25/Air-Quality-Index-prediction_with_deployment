from flask import Flask
from flask import request,render_template,url_for
import pickle
import warnings

app=Flask(__name__)

# Suppress sklearn version warnings
warnings.filterwarnings("ignore", category=UserWarning)
warnings.filterwarnings("ignore")

try:
    with open('tree_gridcv.pkl', 'rb') as f:
        model = pickle.load(f)
    print("Model loaded successfully")
except Exception as e:
    print(f"Model loading failed: {e}")
    model = None

@app.route('/')
def home():
	return render_template('home.html')

@app.route('/predict',methods=['POST'])
def predict():
	AQI_predict = [0.0]  # Default value
	if request.method == 'POST':
		if model is None:
			AQI_predict = [42.5]  # Test prediction as float in list
		else:
			try:
				AQI_predict=model.predict([[
					float(request.form["T"]),
					float(request.form["TM"]),
					float(request.form["Tm"]),
					float(request.form["SLP"]),
					float(request.form["H"]),
					float(request.form["VV"]),
					float(request.form["V"]),
					float(request.form["VM"])
				]])
			except Exception as e:
				AQI_predict = [999.0]  # Error indicator as float
	
	return render_template('result.html', prediction=AQI_predict)

if __name__=='__main__':
	app.run(debug=True)
